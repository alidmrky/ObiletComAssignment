﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ObiletComProgrammingAssignment.Models
{
    public class JourneyModel
    {
        public string OriginLocation { get; set; }
        public string DestinationLocation { get; set; }
    }
}
